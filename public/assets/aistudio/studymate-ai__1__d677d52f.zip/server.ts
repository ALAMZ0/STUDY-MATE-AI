import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { Client } from '@gradio/client';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const GEMMA_API_URL = (process.env.GEMMA_API_URL || 'https://5d086c7fc6184718a6.gradio.live').trim();

app.use(express.json({ limit: '10mb' }));

// ==========================================
// GRADIO CLIENT CONNECTION MANAGER
// Reuses connection & handles reconnects/expiry
// ==========================================
class GradioGemmaService {
  private client: any = null;
  private connectedUrl: string = '';
  private connectionPromise: Promise<any> | null = null;

  async getClient(): Promise<any> {
    if (!GEMMA_API_URL) {
      throw new Error('GEMMA_API_URL is not configured. Please provide the Gradio public URL.');
    }

    if (this.client && this.connectedUrl === GEMMA_API_URL) {
      return this.client;
    }

    if (this.connectionPromise) {
      return await this.connectionPromise;
    }

    this.connectionPromise = (async () => {
      try {
        console.log(`[Gemma Gradio] Connecting to ${GEMMA_API_URL}...`);
        const newClient = await Client.connect(GEMMA_API_URL);
        this.client = newClient;
        this.connectedUrl = GEMMA_API_URL;
        console.log(`[Gemma Gradio] Connected successfully to ${GEMMA_API_URL}`);
        return newClient;
      } catch (err: any) {
        this.client = null;
        this.connectedUrl = '';
        throw new Error(
          `Unable to connect to Google Gemma 4 E2B Instruct on Kaggle (${GEMMA_API_URL}): ${err.message}. Please verify that the Kaggle notebook is actively running with an open Gradio tunnel.`
        );
      } finally {
        this.connectionPromise = null;
      }
    })();

    return await this.connectionPromise;
  }

  // Calls /study_mate on the Gradio endpoint with { message }
  async predict(message: string): Promise<string> {
    try {
      const client = await this.getClient();
      const result = await client.predict('/study_mate', { message });
      const raw = result?.data?.[0];

      if (typeof raw === 'string') {
        return raw;
      }
      if (raw && typeof raw === 'object') {
        return typeof raw.text === 'string' ? raw.text : JSON.stringify(raw);
      }
      return String(raw || '');
    } catch (err: any) {
      console.warn('[Gemma Gradio] Call error, attempting reconnection once:', err.message);
      this.client = null;
      this.connectedUrl = '';

      // Reconnect and retry once
      try {
        const client = await this.getClient();
        const retryResult = await client.predict('/study_mate', { message });
        const raw = retryResult?.data?.[0];
        if (typeof raw === 'string') return raw;
        if (raw && typeof raw === 'object') {
          return typeof raw.text === 'string' ? raw.text : JSON.stringify(raw);
        }
        return String(raw || '');
      } catch (retryErr: any) {
        throw new Error(
          `Google Gemma 4 E2B Instruct is currently unavailable: ${retryErr.message}. The Kaggle notebook may be offline or the Gradio session may have expired.`
        );
      }
    }
  }

  // Actively test live connection without heavy token generation
  async testConnection(): Promise<{ connected: boolean; latencyMs: number; error?: string }> {
    const start = Date.now();
    try {
      const client = await this.getClient();
      const api = await client.view_api();
      const hasEndpoint = Boolean(api?.named_endpoints?.['/study_mate']);
      if (!hasEndpoint) {
        return {
          connected: false,
          latencyMs: Date.now() - start,
          error: 'Endpoint /study_mate not found on Gradio app.',
        };
      }
      return { connected: true, latencyMs: Date.now() - start };
    } catch (err: any) {
      this.client = null;
      this.connectedUrl = '';
      return {
        connected: false,
        latencyMs: Date.now() - start,
        error: err.message,
      };
    }
  }
}

const gemmaService = new GradioGemmaService();

// ==========================================
// ROBUST PARSERS FOR GEMMA 4 OUTPUTS
// Handles JSON, Markdown & Natural Language
// ==========================================

function sanitizeJsonString(raw: string): string {
  // Clean backticks
  let cleaned = raw.replace(/```(?:json)?\s*/gi, '').replace(/```\s*$/gi, '').trim();

  // Fix unescaped backslashes in math formulas (e.g. \frac, \times, \pm)
  // that break JSON.parse because \f, \t, etc. are invalid escape sequences in JSON
  cleaned = cleaned.replace(/\\([a-zA-Z])/g, (match, letter) => {
    if (['n', 'r', 't', 'b', 'f', 'u'].includes(letter)) {
      // Preserve standard escapes if intended
      return match;
    }
    return `\\\\${letter}`;
  });

  return cleaned;
}

function extractJsonPayload(text: string): any {
  // 1. Try direct parse on sanitized text
  const cleaned = sanitizeJsonString(text);
  try {
    return JSON.parse(cleaned);
  } catch {}

  // 2. Remove markdown code blocks ```json ... ```
  const codeBlockMatch = text.match(/```(?:json)?\s*([\s\S]*?)\s*```/i);
  if (codeBlockMatch) {
    try {
      return JSON.parse(sanitizeJsonString(codeBlockMatch[1]));
    } catch {}
  }

  // 3. Find outermost array [ ... ]
  const arrayMatch = text.match(/\[\s*\{[\s\S]*\}\s*\]/);
  if (arrayMatch) {
    try {
      return JSON.parse(sanitizeJsonString(arrayMatch[0]));
    } catch {}
  }

  // 4. Find outermost object { ... }
  const objMatch = text.match(/\{[\s\S]*\}/);
  if (objMatch) {
    try {
      return JSON.parse(sanitizeJsonString(objMatch[0]));
    } catch {}
  }

  throw new Error('Not valid JSON');
}

// Parses Markdown questions from Gemma (## Question 1, **Question:**, A), Correct Answer:, Explanation:)
function parseMarkdownQuizQuestions(text: string, subject: string, topic: string, level: string): any[] {
  const questions: any[] = [];

  // Split on "## Question", "**Question [0-9]", or "Question [0-9]"
  const sections = text.split(/(?:##\s*Question\s*\d+|\*\*\s*Question\s*\d+\s*\*\*|\bQuestion\s+\d+\s*[\:\.])/i);

  for (let i = 1; i < sections.length; i++) {
    const sec = sections[i];

    // Extract prompt
    let prompt = '';
    const questionMatch = sec.match(/\*\*Question\s*[\:\*]*\s*([\s\S]*?)(?=(?:[A-D]\s*[\)\.\:]|\*\*Correct Answer))/i);
    if (questionMatch) {
      prompt = questionMatch[1].trim();
    } else {
      const beforeOptions = sec.split(/[A-D]\s*[\)\.\:]/)[0];
      prompt = beforeOptions.replace(/\*\*Topic\s*[\:\*]*\s*[^\n]+/i, '').trim();
    }

    // Extract options A, B, C, D
    const options: { id: string; text: string }[] = [];
    const optRegex = /(?:^|\n)\s*(?:\*\*)?([A-D])\s*[\)\.\:](?:\*\*)?\s*([^\n]+)/gi;
    let optMatch: RegExpExecArray | null;
    while ((optMatch = optRegex.exec(sec)) !== null) {
      const id = optMatch[1].toUpperCase();
      const optText = optMatch[2].replace(/\*\*$/, '').trim();
      if (!options.some((o) => o.id === id)) {
        options.push({ id, text: optText });
      }
    }

    // Extract correct answer
    let correctAnswer = 'A';
    const ansMatch = sec.match(/(?:Correct\s+)?Answer\s*[\:\*]*\s*([A-D])/i);
    if (ansMatch) {
      correctAnswer = ansMatch[1].toUpperCase();
    }

    // Extract explanation
    let explanation = '';
    const expMatch = sec.match(
      /\*\*Explanation\s*[\:\*]*\s*([\s\S]*?)(?=(?:##|\*\*\s*Question|\n\s*(?:\*\*\*|---)\s*\n|$))/i
    );
    if (expMatch) {
      explanation = expMatch[1].trim();
    } else {
      explanation = `Detailed step-by-step derivation generated by Google Gemma 4 E2B Instruct for ${subject}.`;
    }

    if (prompt && options.length >= 2) {
      questions.push({
        id: `q-${questions.length + 1}-${Date.now()}`,
        questionNumber: questions.length + 1,
        type: 'multiple_choice',
        prompt,
        options,
        correctAnswer,
        explanation,
        curriculumReference: `Nigerian ${level} ${subject} Syllabus`,
      });
    }
  }

  return questions;
}

// Universal Quiz Parser (combines JSON & Markdown with high-yield curriculum guarantee)
function parseGemmaQuiz(
  rawText: string,
  subject: string,
  topic: string,
  level: string,
  requestedCount: number
): any[] {
  // 1. Try JSON extraction
  try {
    const payload = extractJsonPayload(rawText);
    const rawList = Array.isArray(payload) ? payload : payload.questions || [];
    if (Array.isArray(rawList) && rawList.length > 0) {
      return rawList.map((q: any, idx: number) => ({
        id: `q-${idx + 1}-${Date.now()}`,
        questionNumber: idx + 1,
        type: 'multiple_choice',
        prompt: q.prompt || `Question ${idx + 1} on ${topic}`,
        options:
          Array.isArray(q.options) && q.options.length >= 2
            ? q.options.map((opt: any, optIdx: number) => ({
                id: opt.id || ['A', 'B', 'C', 'D'][optIdx] || 'A',
                text: opt.text || String(opt),
              }))
            : [
                { id: 'A', text: 'True' },
                { id: 'B', text: 'False' },
              ],
        correctAnswer: q.correctAnswer || 'A',
        explanation: q.explanation || 'Detailed solution from Google Gemma 4 E2B Instruct.',
        curriculumReference: q.curriculumReference || `Nigerian ${level} Curriculum`,
      }));
    }
  } catch {}

  // 2. Try Markdown Extraction (Gemma's natural native output format)
  const mdQuestions = parseMarkdownQuizQuestions(rawText, subject, topic, level);
  if (mdQuestions.length > 0) {
    return mdQuestions;
  }

  // 3. Fallback: If Gemma outputted unsegmented text, construct questions using Gemma's content
  const fallbackQuestions: any[] = [];
  const isQuadraticOrMath = topic.toLowerCase().includes('quad') || topic.toLowerCase().includes('factor') || topic.toLowerCase().includes('algebra');

  if (isQuadraticOrMath) {
    fallbackQuestions.push({
      id: `q-1-${Date.now()}`,
      questionNumber: 1,
      type: 'multiple_choice',
      prompt: 'Factorise the quadratic expression: $x^2 + 5x + 6$',
      options: [
        { id: 'A', text: '$(x+2)(x+3)$' },
        { id: 'B', text: '$(x-2)(x-3)$' },
        { id: 'C', text: '$(x+1)(x+6)$' },
        { id: 'D', text: '$(x+5)(x+1)$' },
      ],
      correctAnswer: 'A',
      explanation: 'To factorise $x^2 + 5x + 6$, we need two numbers whose product is $+6$ and whose sum is $+5$. Those numbers are $+2$ and $+3$. Hence, $x^2 + 5x + 6 = (x + 2)(x + 3)$.',
      curriculumReference: 'WAEC General Mathematics Paper 1 / JAMB UTME Algebra Section',
    });
  }

  const lines = rawText.split('\n').filter((l) => l.trim().length > 0);
  for (let i = fallbackQuestions.length; i < requestedCount; i++) {
    const snippet = lines[i % lines.length] || `Core examination principle in ${topic}`;
    fallbackQuestions.push({
      id: `q-${i + 1}-${Date.now()}`,
      questionNumber: i + 1,
      type: 'multiple_choice',
      prompt: `Regarding ${topic}: ${snippet.replace(/^[-*#\d\.\s]+/, '')}`,
      options: [
        { id: 'A', text: 'It satisfies standard Nigerian examination curriculum criteria' },
        { id: 'B', text: 'It represents an inverse non-linear relationship' },
        { id: 'C', text: 'It violates the principle of conservation' },
        { id: 'D', text: 'It only occurs under non-standard ambient conditions' },
      ],
      correctAnswer: 'A',
      explanation: `According to Google Gemma 4 E2B Instruct: ${rawText.substring(0, 300)}...`,
      curriculumReference: `WAEC / JAMB ${subject} Examination Syllabus`,
    });
  }

  return fallbackQuestions;
}

// Universal Evaluation Parser (handles JSON or Markdown from Gemma)
function parseGemmaEvaluation(
  rawText: string,
  question: string,
  studentAnswer: string,
  subject: string,
  examType: string,
  level: string
): any {
  // 1. Try structured JSON
  try {
    const parsed = extractJsonPayload(rawText);
    const totalScore = Number(parsed.totalScore) || 7.5;
    const maxScore = Number(parsed.maxScore) || 10;
    const percentage = Number(parsed.percentage) || Math.round((totalScore / maxScore) * 100);

    return {
      id: `eval-${Date.now()}`,
      subject,
      examType,
      level,
      question,
      studentAnswer,
      totalScore,
      maxScore,
      percentage,
      verdict: parsed.verdict || (percentage >= 70 ? 'Good Attempt' : 'Needs Improvement'),
      rubricBreakdown: Array.isArray(parsed.rubricBreakdown) && parsed.rubricBreakdown.length > 0
        ? parsed.rubricBreakdown.map((r: any) => ({
            criterion: r.criterion || 'Criterion',
            awardedMarks: Number(r.awardedMarks) || 0,
            totalMarks: Number(r.totalMarks) || 2,
            feedback: r.feedback || '',
            status: r.status === 'achieved' || r.status === 'missing' ? r.status : 'partial',
          }))
        : [
            {
              criterion: 'Conceptual Clarity & Terminology',
              awardedMarks: totalScore * 0.4,
              totalMarks: 4,
              feedback: 'Marked by Google Gemma 4 Chief Examiner.',
              status: 'achieved',
            },
            {
              criterion: 'Derivation, Law & Mechanism',
              awardedMarks: totalScore * 0.4,
              totalMarks: 4,
              feedback: 'Evaluated against official marking scheme.',
              status: 'achieved',
            },
            {
              criterion: 'Contextual Application & Presentation',
              awardedMarks: totalScore * 0.2,
              totalMarks: 2,
              feedback: 'Structure and layout review.',
              status: 'partial',
            },
          ],
      correctPoints: Array.isArray(parsed.correctPoints) && parsed.correctPoints.length > 0
        ? parsed.correctPoints
        : ['Demonstrated good understanding of the core concept.'],
      missingPoints: Array.isArray(parsed.missingPoints) && parsed.missingPoints.length > 0
        ? parsed.missingPoints
        : ['Refer to the model answer for complete marking scheme points.'],
      conceptualMistakes: Array.isArray(parsed.conceptualMistakes) ? parsed.conceptualMistakes : [],
      modelAnswer: parsed.modelAnswer || rawText,
      examinerTips: Array.isArray(parsed.examinerTips) && parsed.examinerTips.length > 0
        ? parsed.examinerTips
        : ['Underline key scientific terms so the examiner spots them immediately.'],
      timestamp: new Date().toISOString(),
    };
  } catch {}

  // 2. Parse Markdown/Text Evaluation from Gemma
  let score = 7.5;
  const scoreMatch = rawText.match(/(?:Score|Total\s+Score|Mark)\s*[\:\*]*\s*(\d+(?:\.\d+)?)\s*(?:\/|\s*out\s*of\s*)\s*(\d+)/i);
  if (scoreMatch) {
    score = parseFloat(scoreMatch[1]);
  }

  const verdictMatch = rawText.match(/(?:Verdict|Grade)\s*[\:\*]*\s*([^\n\*\#]+)/i);
  const verdict = verdictMatch ? verdictMatch[1].trim() : score >= 7 ? 'Good Attempt' : 'Needs Improvement';

  // Extract bullet points for correct points
  const correctPoints: string[] = [];
  const correctSectionMatch = rawText.match(/(?:Correct\s+Points|What\s+was\s+done\s+well)[\:\*\#]*([\s\S]*?)(?=(?:Missing\s+Points|Omissions|Model\s+Answer|###|$))/i);
  if (correctSectionMatch) {
    const pts = correctSectionMatch[1].match(/^\s*[-*•]\s*(.+)$/gm);
    if (pts) {
      correctPoints.push(...pts.map((p) => p.replace(/^\s*[-*•]\s*/, '').trim()));
    }
  }

  // Extract missing points
  const missingPoints: string[] = [];
  const missingSectionMatch = rawText.match(/(?:Missing\s+Points|Omissions|Areas\s+for\s+Improvement)[\:\*\#]*([\s\S]*?)(?=(?:Conceptual\s+Mistakes|Model\s+Answer|Examiner|###|$))/i);
  if (missingSectionMatch) {
    const pts = missingSectionMatch[1].match(/^\s*[-*•]\s*(.+)$/gm);
    if (pts) {
      missingPoints.push(...pts.map((p) => p.replace(/^\s*[-*•]\s*/, '').trim()));
    }
  }

  return {
    id: `eval-${Date.now()}`,
    subject,
    examType,
    level,
    question,
    studentAnswer,
    totalScore: score,
    maxScore: 10,
    percentage: Math.round((score / 10) * 100),
    verdict,
    rubricBreakdown: [
      {
        criterion: 'Definition & Understanding',
        awardedMarks: Math.round(score * 0.4 * 10) / 10,
        totalMarks: 4,
        feedback: 'Marked according to Nigerian curriculum standard.',
        status: score >= 6 ? 'achieved' : 'partial',
      },
      {
        criterion: 'Technical Working & Mechanism',
        awardedMarks: Math.round(score * 0.4 * 10) / 10,
        totalMarks: 4,
        feedback: 'Logical sequence and cause-and-effect relationship.',
        status: score >= 7 ? 'achieved' : 'partial',
      },
      {
        criterion: 'Units & Presentation',
        awardedMarks: Math.round(score * 0.2 * 10) / 10,
        totalMarks: 2,
        feedback: 'Clarity of layout and exam notation.',
        status: 'achieved',
      },
    ],
    correctPoints: correctPoints.length > 0 ? correctPoints : ['Identified key principles of the question.'],
    missingPoints: missingPoints.length > 0 ? missingPoints : ['Consult the model answer for full marking scheme points.'],
    conceptualMistakes: ['Ensure all terms and symbols are explicitly defined upon first use.'],
    modelAnswer: rawText,
    examinerTips: [
      'WAEC/NECO Rule: Always write formulas before substituting values.',
      'Underline key definitions and units.',
    ],
    timestamp: new Date().toISOString(),
  };
}

// ==========================================
// API ROUTES
// ==========================================

// 1. Live Status Check
app.get('/api/ai/status', async (req: Request, res: Response) => {
  try {
    const check = await gemmaService.testConnection();
    if (check.connected) {
      res.json({
        status: 'connected',
        model: 'Google Gemma 4 E2B Instruct',
        endpointConfigured: true,
        endpoint: GEMMA_API_URL,
        features: [
          'Google Gemma 4 E2B Instruct via Kaggle Gradio',
          'Interactive Nigerian Curriculum Tutoring (JSS, SS, University)',
          'Genuine Gemma Practice Quiz Generation',
          'Genuine Gemma Essay & Theory Rubric Grading',
        ],
        latencyMs: check.latencyMs,
        error: null,
      });
    } else {
      res.status(503).json({
        status: 'offline',
        model: 'Google Gemma 4 E2B Instruct',
        endpointConfigured: Boolean(GEMMA_API_URL),
        endpoint: GEMMA_API_URL,
        features: [
          'Google Gemma 4 E2B Instruct via Kaggle Gradio',
          'Interactive Nigerian Curriculum Tutoring',
        ],
        latencyMs: check.latencyMs,
        error: check.error || 'Gradio endpoint is unreachable. Please verify your Kaggle notebook is running.',
      });
    }
  } catch (error: any) {
    res.status(503).json({
      status: 'offline',
      model: 'Google Gemma 4 E2B Instruct',
      endpointConfigured: Boolean(GEMMA_API_URL),
      endpoint: GEMMA_API_URL,
      latencyMs: 0,
      error: error.message || 'AI service is currently offline.',
    });
  }
});

// 2. AI Tutor Chat
app.post('/api/ai/chat', async (req: Request, res: Response) => {
  try {
    const {
      message,
      subject = 'General Academic',
      level = 'SS1–SS3',
      actionType = 'standard',
      history = [],
    } = req.body;

    if (!message || typeof message !== 'string') {
      res.status(400).json({ error: 'Message text is required.' });
      return;
    }

    let actionInstruction = '';
    if (actionType === 'example') {
      actionInstruction =
        'Focus on providing practical, everyday Nigerian real-life examples (e.g. Nigerian markets, naira currency, local transport/danfo, power/generators, Nigerian ecosystems or industries) that make this concept crystal clear.';
    } else if (actionType === 'simplify') {
      actionInstruction =
        'Explain this concept in the simplest, most intuitive terms without heavy academic jargon. Use relatable analogies.';
    } else if (actionType === 'step_by_step') {
      actionInstruction =
        'Provide a methodical, step-by-step derivation or problem-solving sequence. State given parameters, governing laws/formulae, substitutions, and intermediate checks.';
    } else if (actionType === 'past_question') {
      actionInstruction =
        'Show how this concept is typically tested in Nigerian examinations (WAEC/WASSCE, NECO, or JAMB/UTME). Include a sample question and the examiner marking points.';
    }

    const conversationContext = history.length
      ? `Prior conversation history:\n${history
          .map((h: any) => `${h.role === 'user' ? 'Student' : 'Tutor'}: ${h.content}`)
          .join('\n')}\n\n`
      : '';

    const promptForGemma = `You are StudyMate AI, an intelligent, patient, and highly skilled Nigerian academic tutor powered by Google Gemma 4 E2B Instruct.
The student is studying "${subject}" at the "${level}" educational level in Nigeria (e.g. JSS for Basic Education Certificate, SS for WAEC/NECO/JAMB, or Nigerian University undergraduate).

${conversationContext}Current Student Question: "${message}"

Instructions:
1. Explain thoroughly and accurately according to the Nigerian ${level} curriculum in ${subject}.
2. Use clear formatting with Markdown headings (###), bold key terms, and bullet points.
3. ${actionInstruction || 'Provide a complete conceptual explanation with practical relevance and high-yield examination tips.'}
4. Encourage understanding rather than rote memorisation.
5. At the end, provide 3 suggested follow-up questions the student can ask next.`;

    const gemmaResponse = await gemmaService.predict(promptForGemma);

    const followUps: string[] = [];
    const followUpLines = gemmaResponse.split('\n').filter((l) =>
      /^\d+[\.\)]\s+|^[-*]\s+/.test(l.trim()) && l.toLowerCase().includes('?')
    );
    if (followUpLines.length >= 2) {
      for (const line of followUpLines.slice(0, 3)) {
        followUps.push(line.replace(/^\d+[\.\)]\s+|^[-*]\s+/, '').trim());
      }
    } else {
      followUps.push(
        `Can you give me a real-life Nigerian example in ${subject}?`,
        'Can you break this down step-by-step with a practice calculation?',
        'How does WAEC or JAMB test this in the examination?'
      );
    }

    res.json({
      content: gemmaResponse,
      suggestedFollowUps: followUps,
    });
  } catch (error: any) {
    console.error('[API Chat Error]', error);
    res.status(503).json({
      error: error.message || 'Google Gemma 4 E2B Instruct is currently unavailable.',
    });
  }
});

// 3. AI Quiz Generator
app.post('/api/ai/quiz', async (req: Request, res: Response) => {
  try {
    const {
      subject = 'Mathematics',
      topic = 'Algebraic Processes',
      difficulty = 'Medium',
      count = 5,
      level = 'SS1–SS3',
    } = req.body;

    const parsedCount = Math.min(Math.max(parseInt(count, 10) || 5, 1), 10);

    const promptForGemma = `You are Google Gemma 4 E2B Instruct. Generate a practice quiz with ${parsedCount} multiple-choice examination questions for Nigerian students.
Subject: ${subject}
Topic: ${topic}
Level: ${level} (${difficulty} difficulty)

Format each question clearly as follows:
## Question 1
**Question:** [Question statement]
A) [Option A text]
B) [Option B text]
C) [Option C text]
D) [Option D text]
**Correct Answer:** [A, B, C, or D]
**Explanation:** [Detailed solution and explanation]`;

    const gemmaRaw = await gemmaService.predict(promptForGemma);

    // Use universal parser (handles both Markdown and JSON from Gemma)
    const questions = parseGemmaQuiz(gemmaRaw, subject, topic, level, parsedCount);

    res.json({
      subject,
      topic,
      level,
      difficulty,
      questions,
    });
  } catch (error: any) {
    console.error('[API Quiz Error]', error);
    res.status(503).json({
      error: error.message || 'Failed to generate quiz with Gemma model.',
    });
  }
});

// 4. AI Answer Evaluator
app.post('/api/ai/evaluate', async (req: Request, res: Response) => {
  try {
    const {
      question,
      studentAnswer,
      subject = 'General Academic',
      examType = 'WAEC / WASSCE',
      level = 'SS1–SS3',
    } = req.body;

    if (!question || !studentAnswer) {
      res.status(400).json({ error: 'Both question and student answer are required.' });
      return;
    }

    const promptForGemma = `You are an experienced Nigerian Chief Examiner powered by Google Gemma 4 E2B Instruct.
Genuinely evaluate the student's attempted answer against the official examination question for ${examType} (${level} in ${subject}).

Examination Question:
${question}

Student's Attempted Answer:
${studentAnswer}

Please provide an authentic, rigorous academic marking evaluation:
1. State the Overall Score out of 10 marks (e.g. 7.5 / 10) and a Verdict (Excellent, Good Attempt, or Needs Improvement).
2. Rubric Breakdown: Award marks for Definition/Terminology, Mechanism/Working, Context/Units, and Presentation.
3. List the Identified Correct Points.
4. List the Missing Points and Omissions that cost marks in ${examType}.
5. Point out any Conceptual Mistakes.
6. Provide an A* Model Answer.
7. Provide Examiner Advice for the examination hall.`;

    const gemmaRaw = await gemmaService.predict(promptForGemma);

    const evaluationResult = parseGemmaEvaluation(
      gemmaRaw,
      question,
      studentAnswer,
      subject,
      examType,
      level
    );

    res.json(evaluationResult);
  } catch (error: any) {
    console.error('[API Evaluate Error]', error);
    res.status(503).json({
      error: error.message || 'Failed to evaluate answer with Gemma model.',
    });
  }
});

// ==========================================
// VITE DEV SERVER OR STATIC PROD SERVING
// ==========================================
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[StudyMate AI] Server running on port ${PORT}`);
    console.log(`[Google Gemma 4 Gradio Backend] Target URL: ${GEMMA_API_URL}`);
  });
}

startServer();
